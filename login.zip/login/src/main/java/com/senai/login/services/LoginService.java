package com.senai.login.services;

import com.senai.login.dtos.UsuarioDto;
import org.springframework.stereotype.Service;

@Service
public class LoginService {
    
    public boolean login(UsuarioDto dados) {
        
        
        
    }
    
}
