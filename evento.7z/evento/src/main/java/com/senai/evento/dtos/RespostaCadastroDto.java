package com.senai.evento.dtos;

public class RespostaCadastroDto {
    
    private String mensagem;

    public RespostaCadastroDto() {
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
 
    
    
}
