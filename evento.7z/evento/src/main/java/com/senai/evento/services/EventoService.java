package com.senai.evento.services;

import com.senai.evento.models.EventoModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;


@Service
public class EventoService {
    
    ArrayList<EventoModel> listaEventos = new Arraylist<>();
    
}
