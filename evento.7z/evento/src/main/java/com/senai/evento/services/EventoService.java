package com.senai.evento.services;

import com.senai.evento.dtos.EventoDto;
import com.senai.evento.models.EventoModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;


@Service
public class EventoService {
    
    ArrayList<EventoModel> listaEventos = new ArrayList<>();
    
    public boolean cadastrar (EventoDto dados) {
        
        for (EventoModel eventoItem : listaEventos) {
            
            if (eventoItem.getCodigo().equals(dados.getCodigo())) {
                
                return false;
                
            }
            
        }
        
        EventoModel evento = new EventoModel();
        
        evento.setCodigo(dados.getCodigo());
        evento.setCodigo(dados.getCodigo());
        evento.setDescricao(dados.getDescricao());
        evento.setLocal(dados.getLocal());
        
        listaEventos.add(evento);
        
        return true;
        
    }
    
    public boolean atualizar (EventoDto dados) {
        
        boolean achou = false;
        
        for (EventoModel eventoItem : listaEventos) {
            
            if (eventoItem.getCodigo().equals(dados.getCodigo())) {
                eventoItem.setData(dados.getData());
                eventoItem.setDescricao(dados.getDescricao());
                eventoItem.setLocal(dados.getLocal());
                achou = true;
            }
            
        }
     
        return achou;
        
    }
    
    public ArrayList<EventoDto> obterLista() {
        
        ArrayList<EventoDto> listaDto = new ArrayList<>();
        
        for (EventoModel eventoItem : listaEventos) {
            
            EventoDto dto = new EventoDto();
            dto.setCodigo(eventoItem.getCodigo());
            dto.setData(eventoItem.getData());
            dto.setDescricao(eventoItem.getDescricao());
            dto.setLocal(eventoItem.getLocal());
            
        }
        
        return listaDto;
        
    }
    
}