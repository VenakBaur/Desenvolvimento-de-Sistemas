package com.senai.evento.controllers;

import com.senai.evento.dtos.EventoDto;
import com.senai.evento.dtos.RespostaCadastroDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping ("/evento")
public class EventoController {
    
    @PostMapping
    
    public ResponseEntity<RespostaCadastroDto> cadastrar(@RequestBody EventoDto dados) {
        
        RespostaCadastroDto resposta = new RespostaCadastroDto();
        
        resposta.setMensagem("Cadastro realizado com sucesso!");
        return ResponseEntity.status(HttpStatus.OK).body(resposta);
        
    }
    
}
