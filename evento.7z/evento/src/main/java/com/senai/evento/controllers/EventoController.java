package com.senai.evento.controllers;

import com.senai.evento.dtos.EventoDto;
import com.senai.evento.dtos.RespostaCadastroDto;
import com.senai.evento.services.EventoService;
import jakarta.annotation.Generated;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/evento")
public class EventoController {

    @Autowired
    EventoService servico;

    @PostMapping
    public ResponseEntity<RespostaCadastroDto> cadastrar(@RequestBody EventoDto dados) {

        boolean retorno = servico.cadastrar(dados);

        RespostaCadastroDto resposta = new RespostaCadastroDto();

        if (retorno) {

            resposta.setMensagem("Cadastro realizado com sucesso!");
            return ResponseEntity.status(HttpStatus.OK).body(resposta);

        } else {

            resposta.setMensagem("Erro ao realizar cadastro");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }

    }
    
    @RequestMapping("/atualizar")
    
    @PutMapping
    public ResponseEntity<RespostaCadastroDto> atualizar(@RequestBody EventoDto dados) {

        boolean retorno = servico.atualizar(dados);

        RespostaCadastroDto resposta = new RespostaCadastroDto();

        if (retorno) {

            resposta.setMensagem("Cadastro atualizado com sucesso!");
            return ResponseEntity.status(HttpStatus.OK).body(resposta);

        } else {

            resposta.setMensagem("Erro ao realizar atualização");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }
    
    @RequestMapping("/obter")
    
    @GetMapping
    public ResponseEntity<ArrayList<EventoDto>> obter() {

        return ResponseEntity.ok().body(servico.obterLista());

    }

}
