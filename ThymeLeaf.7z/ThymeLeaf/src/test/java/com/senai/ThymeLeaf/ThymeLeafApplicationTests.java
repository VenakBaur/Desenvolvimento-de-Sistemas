package com.senai.ThymeLeaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeLeafApplicationTests {

	@Test
	void contextLoads() {
	}

}
